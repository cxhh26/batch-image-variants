import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import exifr from 'exifr';
import { addJpegMetadata, createExifSegment, parseGenerationTime } from '../src/metadata.js';
import { getOutputDimensions, md5, peekFolderName, reserveFolderName, validateCount } from '../src/batch.js';

test('validates counts including empty, decimal and out-of-range input', () => {
  assert.equal(validateCount('10'), 10);
  assert.equal(validateCount(500), 500);
  for (const value of ['', ' ', 'abc', 0, -1, 1.5, 501, Infinity]) assert.throws(() => validateCount(value));
});

test('validates real calendar dates and ZIP-supported years', () => {
  const time = parseGenerationTime('2024-01-01T12:34:56');
  assert.equal(time.exifDate, '2024:01:01 12:34:56');
  assert.equal(time.local, '2024-01-01T12:34:56');
  assert.match(time.offset, /^[+-]\d{2}:\d{2}$/);
  assert.equal(parseGenerationTime('2024-02-29T00:00').exifDate, '2024:02:29 00:00:00');
  for (const value of ['2023-02-29T00:00', '2024-13-01T00:00', '2024-04-31T00:00', '2024-01-01T24:01', '1979-12-31T23:59', '2108-01-01T00:00', '', '2024-01-01']) assert.throws(() => parseGenerationTime(value));
});

test('writes EXIF dates, timezone and unique identifier readable by an independent parser', async () => {
  const time = parseGenerationTime('2024-01-01T12:34:56');
  const jpeg = addJpegMetadata(new Uint8Array([0xff, 0xd8, 0xff, 0xd9]), time, 'test_0001/000001/unique');
  const parsed = await exifr.parse(jpeg, { translateValues: false, reviveValues: false });
  assert.equal(parsed.DateTimeOriginal, '2024:01:01 12:34:56');
  assert.equal(parsed.CreateDate, '2024:01:01 12:34:56');
  assert.equal(parsed.ModifyDate, '2024:01:01 12:34:56');
  assert.equal(parsed.OffsetTimeOriginal, time.offset);
  assert.equal(parsed.OffsetTimeDigitized, time.offset);
  assert.equal(parsed.OffsetTime, time.offset);
  assert.equal(parsed.ImageDescription, 'BatchPix test_0001/000001/unique');
  assert.equal(parsed.GPSLatitude, undefined);
});

test('APP1 has valid length and TIFF payload offsets are aligned', () => {
  const segment = createExifSegment(parseGenerationTime('2024-01-01T00:00'), 'a-long-identifier');
  assert.equal(new DataView(segment.buffer).getUint16(2), segment.length - 2);
  assert.deepEqual(Array.from(segment.subarray(0, 2)), [255, 225]);
  const view = new DataView(segment.buffer, 10);
  for (const ifdOffset of [8, view.getUint32(8 + 2 + 3 * 12 + 8, true)]) {
    const count = view.getUint16(ifdOffset, true);
    for (let index = 0; index < count; index += 1) {
      const offset = ifdOffset + 2 + index * 12;
      if (view.getUint16(offset + 2, true) === 2 && view.getUint32(offset + 4, true) > 4) assert.equal(view.getUint32(offset + 8, true) % 2, 0);
    }
  }
});

test('unique metadata yields different hashes and matches Node MD5', () => {
  const time = parseGenerationTime('2024-01-01T00:00');
  const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xd9]);
  const first = addJpegMetadata(jpeg, time, 'batch-1/image-1');
  const second = addJpegMetadata(jpeg, time, 'batch-1/image-2');
  assert.notEqual(md5(first), md5(second));
  assert.equal(md5(first), createHash('md5').update(first).digest('hex'));
  assert.equal(md5(first.subarray(2)), createHash('md5').update(first.subarray(2)).digest('hex'));
  assert.deepEqual(Array.from(jpeg), [255, 216, 255, 217]);
});

test('rejects non-JPEG output', () => {
  assert.throws(() => addJpegMetadata(new Uint8Array([137, 80, 78, 71]), parseGenerationTime('2024-01-01T00:00'), 'test'));
});

test('sizes images without upscaling and protects mobile canvas memory', () => {
  assert.deepEqual(getOutputDimensions(4000, 3000, '2560'), { width: 2560, height: 1920 });
  assert.deepEqual(getOutputDimensions(300, 400, '2048'), { width: 300, height: 400 });
  assert.deepEqual(getOutputDimensions(3000, 4000, 'original'), { width: 3000, height: 4000 });
  assert.throws(() => getOutputDimensions(6000, 4000, 'original'));
  assert.throws(() => getOutputDimensions(10000, 10000, '2560'));
  assert.throws(() => getOutputDimensions(1, 2, '2560'));
  assert.throws(() => getOutputDimensions(400, 300, 'invalid'));
});

test('allocates sequential folders and uses digits when browser storage is unavailable', async () => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  const values = new Map();
  try {
    Object.defineProperty(globalThis, 'localStorage', {
      configurable: true,
      value: { getItem: (key) => values.get(key) || null, setItem: (key, value) => values.set(key, value) },
    });
    assert.equal(peekFolderName(), 'test_0001');
    assert.equal(await reserveFolderName(), 'test_0001');
    assert.equal(await reserveFolderName(), 'test_0002');
    assert.equal(peekFolderName(), 'test_0003');
    values.set('batchpix-next-sequence', 'invalid');
    assert.equal(await reserveFolderName(), 'test_0001');
    Object.defineProperty(globalThis, 'localStorage', {
      configurable: true,
      get() { throw new Error('Storage unavailable'); },
    });
    assert.match(await reserveFolderName(), /^test_\d+_\d{10}$/);
  } finally {
    if (original) Object.defineProperty(globalThis, 'localStorage', original);
    else delete globalThis.localStorage;
  }
});


import { test, expect } from '@playwright/test';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import JSZip from 'jszip';
import exifr from 'exifr';

async function startStaticApp() {
  const types = {
    'index.html': 'text/html',
    'assets/app.js': 'text/javascript',
    'assets/index.css': 'text/css',
    'sw.js': 'text/javascript',
    'manifest.webmanifest': 'application/manifest+json',
    'icon.svg': 'image/svg+xml',
    'icon-192.png': 'image/png',
    'icon-512.png': 'image/png',
    'apple-touch-icon.png': 'image/png',
  };
  const resources = new Map(await Promise.all(Object.entries(types).map(async ([filename, type]) => [`/${filename}`, { type, bytes: await readFile(new URL(`../../dist/${filename}`, import.meta.url)) }])));
  resources.set('/', resources.get('/index.html'));
  const server = createServer((request, response) => {
    const resource = resources.get(new URL(request.url, 'http://localhost').pathname);
    if (!resource) { response.writeHead(404); response.end(); return; }
    response.writeHead(200, { 'Content-Type': resource.type, 'Cache-Control': 'no-store', Vary: 'Origin' });
    response.end(resource.bytes);
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  return {
    origin: `http://127.0.0.1:${server.address().port}`,
    stop: () => server.listening ? new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve())) : Promise.resolve(),
  };
}

async function chooseImage(page) {
  const data = await page.evaluate(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    const context = canvas.getContext('2d');
    context.fillStyle = '#dce5ee';
    context.fillRect(0, 0, 640, 480);
    context.fillStyle = '#738a7c';
    context.fillRect(0, 240, 640, 240);
    context.fillStyle = '#f3dbc0';
    context.beginPath();
    context.arc(475, 110, 45, 0, Math.PI * 2);
    context.fill();
    return canvas.toDataURL('image/png').split(',')[1];
  });
  await page.locator('#image-input').setInputFiles({ name: 'original.png', mimeType: 'image/png', buffer: Buffer.from(data, 'base64') });
  await expect(page.locator('#image-preview')).toBeVisible();
}

test('mobile layout stays within viewport and explains platform limitations', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/叠影/);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.getByRole('button', { name: '使用说明' }).click();
  await expect(page.locator('#help-dialog')).toBeVisible();
  await expect(page.locator('#help-dialog')).toContainText('不是 APK、IPA');
  await page.getByRole('button', { name: '关闭使用说明' }).click();
  await expect(page.locator('#help-dialog')).not.toBeVisible();
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await expect(page.locator('#status-message')).toContainText('请先选择');
});

test('generates visible watermarks, unique MD5, historical EXIF and ZIP folder', async ({ page }) => {
  const errors = [];
  const uploads = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('request', (request) => { if (request.method() !== 'GET') uploads.push(request.url()); });
  await page.goto('/');
  await chooseImage(page);
  await page.locator('#image-count').fill('3');
  await page.locator('#generation-time').fill('2024-01-01T12:34:56');
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await expect(page.locator('#result-section')).toBeVisible();
  await expect(page.locator('#hash-table-body tr')).toHaveCount(3);
  await expect(page.locator('#result-summary')).toContainText('test_0001');
  const downloadEvent = page.waitForEvent('download');
  await page.locator('#download-button').click();
  const download = await downloadEvent;
  expect(download.suggestedFilename()).toBe('test_0001.zip');
  const archive = await JSZip.loadAsync(await readFile(await download.path()));
  const manifest = JSON.parse(await archive.file('test_0001/manifest.json').async('string'));
  expect(manifest.count).toBe(3);
  expect(manifest.generationTime.local).toBe('2024-01-01T12:34:56');
  expect(manifest.generationTime.offset).toBe('+08:00');
  expect(manifest.generationTime.utc).toBe('2024-01-01T04:34:56.000Z');
  const hashes = new Set();
  for (const entry of manifest.images) {
    const file = archive.file(`test_0001/${entry.filename}`);
    const bytes = await file.async('nodebuffer');
    const hash = createHash('md5').update(bytes).digest('hex');
    hashes.add(hash);
    expect(entry.md5).toBe(hash);
    const metadata = await exifr.parse(bytes, { reviveValues: false });
    expect(metadata.DateTimeOriginal).toBe('2024:01:01 12:34:56');
    expect(metadata.OffsetTimeOriginal).toBe('+08:00');
    expect(file.date.toISOString()).toBe('2024-01-01T12:34:56.000Z');
  }
  expect(hashes.size).toBe(3);
  const differentDecodedPixels = await page.evaluate(async () => {
    const images = Array.from(document.querySelectorAll('#result-previews img'));
    await Promise.all(images.map((image) => image.decode()));
    const getPixels = (image) => {
      const canvas = document.createElement('canvas');
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext('2d');
      context.drawImage(image, 0, 0);
      return context.getImageData(0, 0, canvas.width, canvas.height).data;
    };
    const first = getPixels(images[0]);
    const second = getPixels(images[1]);
    return first.some((value, index) => value !== second[index]);
  });
  expect(differentDecodedPixels).toBe(true);
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await expect(page.locator('#result-summary')).toContainText('test_0002');
  const secondBatchHashes = await page.locator('#hash-table-body td:nth-child(2)').allTextContents();
  expect(secondBatchHashes).toHaveLength(3);
  expect(secondBatchHashes.every((hash) => !hashes.has(hash))).toBe(true);
  expect(errors).toEqual([]);
  expect(uploads).toEqual([]);
});

test('supports cancelling and generating again', async ({ page }) => {
  await page.goto('/');
  await chooseImage(page);
  await page.locator('#image-count').fill('100');
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await page.locator('#cancel-button').click();
  await expect(page.locator('#status-message')).toContainText('已取消');
  await expect(page.locator('#result-section')).not.toBeVisible();
  await expect(page.locator('#generate-button')).toBeEnabled();
  await page.locator('#image-count').fill('1');
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await expect(page.locator('#result-section')).toBeVisible();
});

test('rejects unsupported files and protects existing selection', async ({ page }) => {
  await page.goto('/');
  await chooseImage(page);
  await page.locator('#image-input').setInputFiles({ name: 'invalid.txt', mimeType: 'text/plain', buffer: Buffer.from('not an image') });
  await expect(page.locator('#status-message')).toHaveClass(/is-error/);
  await expect(page.locator('#image-preview')).toBeVisible();
  await page.locator('#image-count').fill('1');
  await page.getByRole('button', { name: '开始批量生成' }).click();
  await expect(page.locator('#result-section')).toBeVisible();
});

test('production app works offline after its HTTP server stops', async ({ page }) => {
  const app = await startStaticApp();
  try {
    await page.goto(app.origin);
    await page.evaluate(async () => {
      await navigator.serviceWorker.ready;
      if (!navigator.serviceWorker.controller) await new Promise((resolve) => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true }));
    });
    await app.stop();
    await page.reload();
    await expect(page.getByRole('heading', { name: '选择原图' })).toBeVisible();
    await chooseImage(page);
    await page.locator('#image-count').fill('1');
    await page.getByRole('button', { name: '开始批量生成' }).click();
    await expect(page.locator('#result-section')).toBeVisible();
  } finally {
    await app.stop();
  }
});


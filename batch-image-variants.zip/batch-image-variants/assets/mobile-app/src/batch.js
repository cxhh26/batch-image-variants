import JSZip from 'jszip';
import SparkMD5 from 'spark-md5';
import { addJpegMetadata, parseGenerationTime } from './metadata.js';

export const MAX_COUNT = 500;
export const MAX_ARCHIVE_BYTES = 180 * 1024 * 1024;
const COUNTER_KEY = 'batchpix-next-sequence';
const POSITIONS = ['bottom-right', 'bottom-left', 'top-right', 'top-left'];

export function validateCount(value) {
  const count = Number(value);
  if (!String(value).trim() || !Number.isInteger(count) || count < 1 || count > MAX_COUNT) throw new Error(`生成数量需要是 1–${MAX_COUNT} 之间的整数。`);
  return count;
}

export function getOutputDimensions(width, height, size) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 16 || height < 16) throw new Error('图片宽和高都需要至少 16 像素，以保证水印可见。');
  if (width * height > 80_000_000) throw new Error('原图超过 8000 万像素，请先缩小图片后重试。');
  if (!['original', '2048', '2560'].includes(String(size))) throw new Error('请选择有效的输出尺寸。');
  if (size === 'original' && width * height > 16_000_000) throw new Error('手机端原始尺寸最多支持 1600 万像素，请改用「手机友好」尺寸。');
  const scale = size === 'original' ? 1 : Math.min(1, Number(size) / Math.max(width, height));
  return { width: Math.max(1, Math.round(width * scale)), height: Math.max(1, Math.round(height * scale)) };
}

function getSequence(storage) {
  const sequence = Number(storage.getItem(COUNTER_KEY) || 1);
  return Number.isSafeInteger(sequence) && sequence > 0 && sequence < 1_000_000_000 ? sequence : 1;
}

export function peekFolderName() {
  try {
    return `test_${String(getSequence(localStorage)).padStart(4, '0')}`;
  } catch {
    return 'test_时间数字编码';
  }
}

export async function reserveFolderName() {
  const reserve = () => {
    try {
      const sequence = getSequence(localStorage);
      localStorage.setItem(COUNTER_KEY, String(sequence + 1));
      return `test_${String(sequence).padStart(4, '0')}`;
    } catch {
      const suffix = String(Number.parseInt(randomId().slice(0, 8), 16)).padStart(10, '0');
      return `test_${Date.now()}_${suffix}`;
    }
  };
  return globalThis.navigator?.locks ? navigator.locks.request('batchpix-sequence', reserve) : reserve();
}

export function randomId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

export function md5(bytes) {
  return SparkMD5.ArrayBuffer.hash(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
}

export function drawWatermark(context, width, height, code, position) {
  const padding = Math.max(1, Math.round(Math.min(width, height) * 0.025));
  let fontSize = Math.max(1, Math.round(Math.min(width, height) * 0.046));
  context.save();
  context.textBaseline = 'middle';
  context.textAlign = 'left';
  context.font = `600 ${fontSize}px monospace`;
  while (fontSize > 1 && context.measureText(code).width + padding * 4 > width) {
    fontSize -= 1;
    context.font = `600 ${fontSize}px monospace`;
  }
  const boxWidth = Math.min(width, Math.ceil(context.measureText(code).width + padding * 2));
  const boxHeight = Math.min(height, Math.ceil(fontSize * 1.6));
  const left = position.endsWith('right') ? Math.max(0, width - boxWidth - padding) : Math.min(padding, width - boxWidth);
  const top = position.startsWith('bottom') ? Math.max(0, height - boxHeight - padding) : Math.min(padding, height - boxHeight);
  context.fillStyle = 'rgba(15, 20, 34, 0.62)';
  context.fillRect(left, top, boxWidth, boxHeight);
  context.fillStyle = '#ffffff';
  context.fillText(code, left + padding, top + boxHeight / 2);
  context.restore();
}

function canvasJpeg(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('图片编码失败，可能是手机内存不足，请减小输出尺寸。')), 'image/jpeg', 0.92);
  });
}

function checkCancelled(signal) {
  if (signal?.aborted) throw new DOMException('已取消本次生成。', 'AbortError');
}

const nextFrame = () => new Promise((resolve) => setTimeout(resolve, 0));

export async function generateBatch({ image, originalName, count: requestedCount, generationTime, position, size, folderName, signal, onProgress = () => {} }) {
  const count = validateCount(requestedCount);
  const time = parseGenerationTime(generationTime);
  const zipDate = new Date(`${time.local}Z`);
  if (!POSITIONS.includes(position)) throw new Error('请选择有效的水印位置。');
  if (!/^test_\d+(?:_\d+)?$/.test(folderName)) throw new Error('输出文件夹名称不合法。');
  const dimensions = getOutputDimensions(image.naturalWidth, image.naturalHeight, size);
  const canvas = document.createElement('canvas');
  canvas.width = dimensions.width;
  canvas.height = dimensions.height;
  const context = canvas.getContext('2d', { alpha: false });
  if (!context) throw new Error('当前浏览器无法处理图片，请使用系统浏览器。');
  const zip = new JSZip();
  const hashes = new Set();
  const entries = [];
  const batchId = randomId();
  let totalBytes = 0;
  try {
    for (let index = 1; index <= count; index += 1) {
      checkCancelled(signal);
      const code = String(index).padStart(6, '0');
      const filename = `${code}.jpg`;
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      drawWatermark(context, canvas.width, canvas.height, code, position);
      const jpeg = new Uint8Array(await (await canvasJpeg(canvas)).arrayBuffer());
      let bytes;
      let hash;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        bytes = addJpegMetadata(jpeg, time, `${batchId}/${code}/${randomId()}`);
        hash = md5(bytes);
        if (!hashes.has(hash)) break;
      }
      if (hashes.has(hash)) throw new Error('发现重复 MD5，已停止生成，请重试。');
      hashes.add(hash);
      totalBytes += bytes.length;
      if (totalBytes > MAX_ARCHIVE_BYTES || (index === 1 && bytes.length * count > MAX_ARCHIVE_BYTES)) throw new Error('预计图片总量超过手机安全上限 180 MB，请减少数量或使用轻量尺寸后重试。');
      zip.file(`${folderName}/${filename}`, bytes, { date: zipDate, createFolders: false });
      entries.push({ filename, code, md5: hash, bytes: bytes.length });
      onProgress({ phase: 'images', completed: index, total: count, percent: Math.round(index / count * 88), preview: index <= 4 ? new Blob([bytes], { type: 'image/jpeg' }) : null });
      await nextFrame();
    }
    checkCancelled(signal);
    const manifest = { folder: folderName, source: originalName, count, format: 'JPEG', dimensions, watermark: { position, numbering: '000001' }, generationTime: { local: time.local, offset: time.offset, utc: time.iso }, note: '指定时间为用户设置的 EXIF 元数据，并非真实拍摄时间；MD5 仅表示文件字节差异。', images: entries };
    zip.file(`${folderName}/manifest.json`, JSON.stringify(manifest, null, 2), { date: zipDate, createFolders: false });
    const csv = ['filename,watermark,md5,exif_datetime,timezone_offset', ...entries.map((entry) => [entry.filename, entry.code, entry.md5, time.exifDate, time.offset].map((cell) => `"${cell}"`).join(','))].join('\r\n');
    zip.file(`${folderName}/md5.csv`, `\ufeff${csv}\r\n`, { date: zipDate, createFolders: false });
    const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE', mimeType: 'application/zip' }, (metadata) => {
      checkCancelled(signal);
      onProgress({ phase: 'zip', completed: count, total: count, percent: 88 + Math.round(metadata.percent * 0.12) });
    });
    checkCancelled(signal);
    return { blob, folderName, entries, dimensions, time, totalBytes };
  } finally {
    canvas.width = 1;
    canvas.height = 1;
  }
}


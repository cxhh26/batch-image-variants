import './styles.css';
import JSZip from 'jszip';
import { generateBatch, peekFolderName, reserveFolderName, validateCount } from './batch.js';
import { parseGenerationTime } from './metadata.js';

const element = (id) => document.getElementById(id);
const imageInput = element('image-input');
const countInput = element('image-count');
const timeInput = element('generation-time');
const sourcePreview = element('source-preview');
let currentImage = null;
let currentFile = null;
let sourceUrl = null;
let result = null;
let controller = null;
let selectionVersion = 0;
let busy = false;
const previewUrls = [];
const downloadUrls = new Set();

function formatBytes(bytes) {
  return bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(bytes / 1024)} KB`;
}

function setNow() {
  const now = new Date();
  const pad = (number) => String(number).padStart(2, '0');
  timeInput.value = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
}

function showStatus(message, error = false) {
  const status = element('status-message');
  status.textContent = message;
  status.classList.toggle('is-error', error);
  status.hidden = !message;
}

function clearResult() {
  result = null;
  previewUrls.forEach((url) => URL.revokeObjectURL(url));
  previewUrls.length = 0;
  element('result-section').hidden = true;
  element('result-previews').replaceChildren();
  element('hash-table-body').replaceChildren();
}

function updateCount() {
  document.querySelectorAll('[data-count]').forEach((button) => button.classList.toggle('selected', Number(button.dataset.count) === Number(countInput.value)));
}

function setBusy(value) {
  busy = value;
  element('settings-fields').disabled = value;
  imageInput.disabled = value;
  element('generate-button').disabled = value;
  element('generate-button').innerHTML = value ? '<span class="spinner" aria-hidden="true"></span> 正在本地生成…' : '<span aria-hidden="true">✧</span> 开始批量生成 <span class="button-arrow" aria-hidden="true">→</span>';
  element('cancel-button').hidden = !value;
  element('cancel-button').disabled = false;
  element('upload-zone').classList.toggle('is-disabled', value);
}

async function selectImage(file) {
  if (!file || busy) return;
  const version = ++selectionVersion;
  showStatus('');
  const supportedType = /^image\/(jpeg|png|webp|heic|heif)$/.test(file.type);
  const supportedExtension = /\.(jpe?g|png|webp|heic|heif)$/i.test(file.name);
  if ((!supportedType && !(file.type === '' && supportedExtension)) || file.size > 30 * 1024 * 1024) {
    imageInput.value = '';
    showStatus('请选择 30 MB 以内的 JPG、PNG、WebP 或浏览器支持的 HEIC 图片。', true);
    return;
  }
  const candidateUrl = URL.createObjectURL(file);
  const image = new Image();
  image.src = candidateUrl;
  try {
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('无法读取这张图片。若为 HEIC，请先在相册导出为 JPG；也可以尝试系统浏览器。'));
    });
    if (version !== selectionVersion || busy) {
      URL.revokeObjectURL(candidateUrl);
      return;
    }
    if (image.naturalWidth < 16 || image.naturalHeight < 16 || image.naturalWidth * image.naturalHeight > 80_000_000) throw new Error('图片宽高需至少 16 像素，且原图不能超过 8000 万像素。');
    if (sourceUrl) URL.revokeObjectURL(sourceUrl);
    sourceUrl = candidateUrl;
    currentImage = image;
    currentFile = file;
    sourcePreview.src = sourceUrl;
    sourcePreview.alt = `原图预览：${file.name}`;
    element('upload-empty').hidden = true;
    element('image-preview').hidden = false;
    element('source-description').textContent = `${file.name} · ${image.naturalWidth} × ${image.naturalHeight} · ${formatBytes(file.size)}`;
    element('source-description').title = file.name;
    clearResult();
  } catch (error) {
    URL.revokeObjectURL(candidateUrl);
    if (version === selectionVersion) {
      imageInput.value = '';
      showStatus(error.message, true);
    }
  }
}

function addPreview(blob, index) {
  const url = URL.createObjectURL(blob);
  previewUrls.push(url);
  const figure = document.createElement('figure');
  const image = document.createElement('img');
  image.src = url;
  image.alt = `带数字水印的第 ${index} 张图片`;
  const caption = document.createElement('figcaption');
  caption.textContent = `${String(index).padStart(6, '0')}.jpg`;
  const save = document.createElement('button');
  save.type = 'button';
  save.textContent = '保存单张 ↓';
  save.addEventListener('click', () => downloadBlob(blob, caption.textContent));
  figure.append(image, caption, save);
  element('result-previews').append(figure);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  downloadUrls.add(url);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    downloadUrls.delete(url);
  }, 120_000);
}

function showResult() {
  element('result-summary').textContent = `${result.entries.length} 张图片 · ${result.folderName} · ${formatBytes(result.blob.size)}`;
  const rows = document.createDocumentFragment();
  result.entries.forEach((entry) => {
    const row = document.createElement('tr');
    const filename = document.createElement('td');
    const hash = document.createElement('td');
    filename.textContent = entry.filename;
    hash.textContent = entry.md5;
    row.append(filename, hash);
    rows.append(row);
  });
  element('hash-table-body').append(rows);
  const zipFile = new File([result.blob], `${result.folderName}.zip`, { type: 'application/zip' });
  try {
    element('share-button').hidden = !navigator.canShare?.({ files: [zipFile] });
  } catch {
    element('share-button').hidden = true;
  }
  element('folder-button').hidden = typeof window.showDirectoryPicker !== 'function';
  element('result-section').hidden = false;
  element('result-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

element('generate-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (busy) return;
  if (!currentImage) {
    showStatus('请先选择一张原图。', true);
    element('upload-zone').scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }
  try {
    validateCount(countInput.value);
    parseGenerationTime(timeInput.value);
  } catch (error) {
    showStatus(error.message, true);
    return;
  }
  clearResult();
  showStatus('');
  setBusy(true);
  controller = new AbortController();
  element('progress-section').hidden = false;
  element('generation-progress').value = 0;
  element('progress-label').textContent = '0%';
  element('progress-title').textContent = '正在为图片创建独立版本…';
  element('progress-detail').textContent = '请保持页面在前台，生成过程中不要锁屏。';
  let wakeLock;
  try {
    if (navigator.wakeLock) {
      try { wakeLock = await navigator.wakeLock.request('screen'); } catch {}
    }
    const folderName = await reserveFolderName();
    result = await generateBatch({ image: currentImage, originalName: currentFile.name, count: countInput.value, generationTime: timeInput.value, position: element('watermark-position').value, size: element('output-size').value, folderName, signal: controller.signal, onProgress(progress) {
      element('generation-progress').value = progress.percent;
      element('progress-label').textContent = `${progress.percent}%`;
      element('progress-detail').textContent = progress.phase === 'zip' ? '正在打包 ZIP 和 MD5 清单，请稍候…' : `已生成 ${progress.completed} / ${progress.total} 张，请保持页面在前台。`;
      if (progress.preview) addPreview(progress.preview, progress.completed);
    } });
    element('progress-section').hidden = true;
    showResult();
  } catch (error) {
    clearResult();
    element('progress-section').hidden = true;
    showStatus(error.name === 'AbortError' ? '已取消。本次临时图片已释放，原图未被修改。' : error.message || '生成失败，请减少数量或更换浏览器后重试。', error.name !== 'AbortError');
  } finally {
    try { await wakeLock?.release(); } catch {}
    setBusy(false);
    controller = null;
    element('folder-preview').textContent = peekFolderName();
  }
});

imageInput.addEventListener('change', () => selectImage(imageInput.files[0]));
countInput.addEventListener('input', updateCount);
element('count-minus').addEventListener('click', () => { countInput.value = Math.max(1, (Number(countInput.value) || 1) - 1); updateCount(); });
element('count-plus').addEventListener('click', () => { countInput.value = Math.min(500, (Number(countInput.value) || 0) + 1); updateCount(); });
document.querySelectorAll('[data-count]').forEach((button) => button.addEventListener('click', () => { countInput.value = button.dataset.count; updateCount(); }));
element('now-button').addEventListener('click', setNow);
element('cancel-button').addEventListener('click', () => { controller?.abort(); element('cancel-button').disabled = true; });
element('download-button').addEventListener('click', () => { if (result) downloadBlob(result.blob, `${result.folderName}.zip`); });
element('watermark-position').addEventListener('change', (event) => { element('preview-watermark').dataset.position = event.target.value; });

element('share-button').addEventListener('click', async () => {
  if (!result) return;
  try {
    const file = new File([result.blob], `${result.folderName}.zip`, { type: 'application/zip' });
    await navigator.share({ files: [file], title: result.folderName });
  } catch (error) {
    if (error.name !== 'AbortError') showStatus('当前系统无法分享 ZIP，请使用「下载全部图片 ZIP」。', true);
  }
});

element('folder-button').addEventListener('click', async () => {
  if (!result) return;
  const currentResult = result;
  const button = element('folder-button');
  let destination;
  let created = false;
  try {
    button.disabled = true;
    const parent = await window.showDirectoryPicker({ mode: 'readwrite' });
    try {
      await parent.getDirectoryHandle(currentResult.folderName);
      throw new Error('此位置已存在同名文件夹，请选择其他位置，避免覆盖。');
    } catch (error) {
      if (error.name !== 'NotFoundError') throw error;
    }
    destination = await parent.getDirectoryHandle(currentResult.folderName, { create: true });
    created = true;
    const archive = await JSZip.loadAsync(currentResult.blob);
    for (const entry of Object.values(archive.files)) {
      if (entry.dir) continue;
      const file = await destination.getFileHandle(entry.name.split('/').pop(), { create: true });
      const writable = await file.createWritable();
      try {
        await writable.write(await entry.async('uint8array'));
        await writable.close();
      } catch (error) {
        try { await writable.abort(); } catch {}
        throw error;
      }
    }
    showStatus(`已保存到 ${currentResult.folderName} 文件夹。图片 EXIF 已保留，系统文件时间由设备决定。`);
  } catch (error) {
    if (error.name !== 'AbortError') showStatus(`${error.message || '保存失败，请下载 ZIP 后解压。'}${created ? ' 已写入部分文件，可删除该文件夹后重试。' : ''}`, true);
  } finally {
    button.disabled = false;
  }
});

const uploadZone = element('upload-zone');
uploadZone.addEventListener('dragover', (event) => { event.preventDefault(); if (!busy) uploadZone.classList.add('drag-over'); });
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
uploadZone.addEventListener('drop', (event) => { event.preventDefault(); uploadZone.classList.remove('drag-over'); if (!busy) selectImage(event.dataTransfer.files[0]); });

const helpDialog = element('help-dialog');
element('help-button').addEventListener('click', () => { if (helpDialog.showModal) helpDialog.showModal(); else helpDialog.setAttribute('open', ''); });
element('close-help').addEventListener('click', () => { if (helpDialog.close) helpDialog.close(); else helpDialog.removeAttribute('open'); });
helpDialog.addEventListener('click', (event) => { if (event.target === helpDialog && helpDialog.close) helpDialog.close(); });

window.addEventListener('beforeunload', (event) => {
  if (busy) { event.preventDefault(); event.returnValue = ''; }
});
window.addEventListener('storage', () => { element('folder-preview').textContent = peekFolderName(); });

setNow();
element('folder-preview').textContent = peekFolderName();

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}


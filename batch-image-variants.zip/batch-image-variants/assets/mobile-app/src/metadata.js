const encoder = new TextEncoder();

export function parseGenerationTime(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value);
  if (!match) throw new Error('请选择完整的生成日期和时间。');
  const [year, month, day, hour, minute, second] = match.slice(1).map((part) => Number(part || 0));
  const date = new Date(year, month - 1, day, hour, minute, second);
  if (year < 1980 || year > 2107 || date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day || date.getHours() !== hour || date.getMinutes() !== minute || date.getSeconds() !== second) {
    throw new Error('请输入有效时间，年份范围为 1980–2107；夏令时跳过的时间不可用。');
  }
  const pad = (number) => String(number).padStart(2, '0');
  const offsetMinutes = -date.getTimezoneOffset();
  const offset = `${offsetMinutes >= 0 ? '+' : '-'}${pad(Math.floor(Math.abs(offsetMinutes) / 60))}:${pad(Math.abs(offsetMinutes) % 60)}`;
  const exifDate = `${year}:${pad(month)}:${pad(day)} ${pad(hour)}:${pad(minute)}:${pad(second)}`;
  return { date, exifDate, offset, local: `${year}-${pad(month)}-${pad(day)}T${pad(hour)}:${pad(minute)}:${pad(second)}`, iso: date.toISOString() };
}

function writeIfd(view, bytes, offset, entries, payloadOffset) {
  view.setUint16(offset, entries.length, true);
  entries.forEach((entry, index) => {
    const entryOffset = offset + 2 + index * 12;
    view.setUint16(entryOffset, entry.tag, true);
    view.setUint16(entryOffset + 2, entry.type, true);
    if (entry.type === 4) {
      view.setUint32(entryOffset + 4, 1, true);
      view.setUint32(entryOffset + 8, entry.value, true);
    } else {
      const encoded = encoder.encode(`${entry.value}\0`);
      view.setUint32(entryOffset + 4, encoded.length, true);
      if (encoded.length <= 4) {
        bytes.set(encoded, entryOffset + 8);
      } else {
        view.setUint32(entryOffset + 8, payloadOffset, true);
        bytes.set(encoded, payloadOffset);
        payloadOffset += encoded.length + encoded.length % 2;
      }
    }
  });
  return payloadOffset;
}

export function createExifSegment(time, uniqueId) {
  const ascii = (tag, value) => ({ tag, type: 2, value });
  const zerothOffset = 8;
  const zerothCount = 4;
  const exifOffset = zerothOffset + 2 + zerothCount * 12 + 4;
  const zeroth = [ascii(0x010e, `BatchPix ${uniqueId}`), ascii(0x0131, 'BatchPix Mobile'), ascii(0x0132, time.exifDate), { tag: 0x8769, type: 4, value: exifOffset }];
  const exif = [ascii(0x9003, time.exifDate), ascii(0x9004, time.exifDate), ascii(0x9010, time.offset), ascii(0x9011, time.offset), ascii(0x9012, time.offset)];
  const payloadOffset = exifOffset + 2 + exif.length * 12 + 4;
  const payloadLength = [...zeroth, ...exif].reduce((total, entry) => {
    if (entry.type !== 2 || entry.value.length + 1 <= 4) return total;
    const length = encoder.encode(entry.value).length + 1;
    return total + length + length % 2;
  }, 0);
  const tiff = new Uint8Array(payloadOffset + payloadLength);
  const view = new DataView(tiff.buffer);
  tiff.set([0x49, 0x49, 0x2a, 0]);
  view.setUint32(4, zerothOffset, true);
  const nextPayload = writeIfd(view, tiff, zerothOffset, zeroth, payloadOffset);
  writeIfd(view, tiff, exifOffset, exif, nextPayload);
  const segment = new Uint8Array(tiff.length + 10);
  if (segment.length - 2 > 65535) throw new Error('图片元数据超出 JPEG 长度限制。');
  segment.set([0xff, 0xe1]);
  new DataView(segment.buffer).setUint16(2, segment.length - 2);
  segment.set([0x45, 0x78, 0x69, 0x66, 0, 0], 4);
  segment.set(tiff, 10);
  return segment;
}

export function addJpegMetadata(jpeg, time, uniqueId) {
  if (!(jpeg instanceof Uint8Array) || jpeg[0] !== 0xff || jpeg[1] !== 0xd8) throw new Error('浏览器未能输出 JPG，请换用系统浏览器。');
  const segment = createExifSegment(time, uniqueId);
  const output = new Uint8Array(jpeg.length + segment.length);
  output.set(jpeg.subarray(0, 2));
  output.set(segment, 2);
  output.set(jpeg.subarray(2), segment.length + 2);
  return output;
}


import { defineConfig } from 'vite';
import { createHash } from 'node:crypto';

function offlineApp() {
  return {
    name: 'batchpix-offline',
    apply: 'build',
    generateBundle(options, bundle) {
      const files = [...new Set(['/', '/index.html', '/manifest.webmanifest', '/icon.svg', '/icon-192.png', '/icon-512.png', '/apple-touch-icon.png', ...Object.keys(bundle).map((file) => `/${file}`)])];
      const hash = createHash('sha256').update(Object.values(bundle).map((entry) => entry.code || String(entry.source)).join('')).digest('hex').slice(0, 16);
      const source = `const CACHE_NAME = 'batchpix-${hash}';
const APP_FILES = ${JSON.stringify(files)};
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_FILES)));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('batchpix-') && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  event.respondWith(caches.open(CACHE_NAME).then((cache) => cache.match(event.request, { ignoreVary: true })).then((cached) => cached || fetch(event.request)));
});`;
      this.emitFile({ type: 'asset', fileName: 'sw.js', source });
    },
  };
}

export default defineConfig({
  plugins: [offlineApp()],
  build: {
    target: ['es2020', 'safari14'],
    rollupOptions: {
      output: {
        entryFileNames: 'assets/app.js',
        chunkFileNames: 'assets/[name].js',
        assetFileNames: 'assets/[name][extname]',
      },
    },
  },
});


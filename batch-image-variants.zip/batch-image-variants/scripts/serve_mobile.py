import argparse
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


APP_ROOT = Path(__file__).resolve().parents[1] / "assets" / "mobile-app" / "dist"


def make_handler(root=APP_ROOT):
    root = root.resolve()
    files = {f"/{path.relative_to(root).as_posix()}": path for path in root.rglob("*") if path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root)}
    if "/index.html" not in files:
        raise FileNotFoundError("缺少随包手机应用，请恢复 assets/mobile-app/dist 或按手机参考重新构建。")
    files["/"] = files["/index.html"]

    class AppHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.respond(False)

        def do_HEAD(self):
            self.respond(True)

        def do_POST(self):
            self.send_error(405, "This app does not upload images")

        def respond(self, head_only):
            path = files.get(urlsplit(self.path).path)
            if path is None:
                self.send_error(404)
                return
            try:
                content = path.read_bytes()
            except OSError:
                self.send_error(404)
                return
            content_type = {".js": "text/javascript", ".webmanifest": "application/manifest+json"}.get(path.suffix, mimetypes.guess_type(path.name)[0] or "application/octet-stream")
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            if not head_only:
                self.wfile.write(content)

    return AppHandler


def main():
    parser = argparse.ArgumentParser(description="启动随包的手机图片工具；仅分发静态页面，不接收图片。")
    parser.add_argument("--host", default="127.0.0.1", help="手机局域网访问时显式设置 0.0.0.0。")
    parser.add_argument("--port", default=8765, type=int)
    arguments = parser.parse_args()
    if not 0 <= arguments.port <= 65535:
        parser.error("端口必须在 0–65535 之间。")
    try:
        server = ThreadingHTTPServer((arguments.host, arguments.port), make_handler())
    except (OSError, ValueError) as error:
        parser.exit(2, f"无法启动：{error}\n")
    display_host = "127.0.0.1" if arguments.host == "0.0.0.0" else arguments.host
    print(json.dumps({"url": f"http://{display_host}:{server.server_port}", "listen_host": arguments.host, "port": server.server_port, "notice": "手机与电脑同一网络时，用电脑局域网 IP 替换地址中的 127.0.0.1；图片在手机处理。"}, ensure_ascii=False), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


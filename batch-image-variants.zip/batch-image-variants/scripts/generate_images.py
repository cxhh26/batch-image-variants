import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
import uuid
import warnings
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    from PIL import Image, ImageDraw, ImageFont, ImageOps
except ImportError:
    raise SystemExit("缺少 Pillow，请在虚拟环境执行：python -m pip install -r scripts/requirements.txt")


MAX_COUNT = 500
MAX_INPUT_BYTES = 30 * 1024 * 1024
MAX_OUTPUT_BYTES = 180 * 1024 * 1024
POSITIONS = ("bottom-right", "bottom-left", "top-right", "top-left")
SIZES = ("2560", "2048", "original")


def parse_time(value, timezone_name):
    try:
        zone = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as error:
        raise ValueError(f"未知时区：{timezone_name}；请使用 Asia/Shanghai 等 IANA 时区。") from error
    try:
        selected = datetime.fromisoformat(value) if value else datetime.now(zone).replace(microsecond=0)
    except ValueError as error:
        raise ValueError("日期无效，请使用 2024-01-01T00:00:00 或包含时区偏移的 ISO 时间。") from error
    if selected.tzinfo is None:
        naive = selected
        selected = selected.replace(tzinfo=zone)
        if selected.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None) != naive:
            raise ValueError("此本地时间因夏令时切换不存在，请选择其他时间。")
    if not 1980 <= selected.year <= 2107:
        raise ValueError("指定年份必须在 1980–2107 之间。")
    if selected.microsecond or selected.utcoffset().total_seconds() % 60:
        raise ValueError("仅支持整秒时间与整分钟时区偏移。")
    return selected


def time_fields(selected):
    raw_offset = selected.strftime("%z")
    return {
        "local": selected.strftime("%Y-%m-%dT%H:%M:%S"),
        "offset": f"{raw_offset[:3]}:{raw_offset[3:]}",
        "utc": selected.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
    }


def output_dimensions(width, height, size):
    if width < 16 or height < 16:
        raise ValueError("图片宽高需要至少各 16 像素。")
    if width * height > 80_000_000:
        raise ValueError("原图超过 8000 万像素，请先缩小。")
    if size not in SIZES:
        raise ValueError("尺寸必须为 2560、2048 或 original。")
    if size == "original":
        if width * height > 16_000_000:
            raise ValueError("原始尺寸最多支持 1600 万像素，请选择 2560 或 2048。")
        return width, height
    scale = min(1, int(size) / max(width, height))
    return max(1, round(width * scale)), max(1, round(height * scale))


def load_source(path, size):
    if not path.is_file():
        raise ValueError(f"原图不存在或不是文件：{path}")
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError("原图不能超过 30 MB。")
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        with Image.open(path) as source:
            if source.format not in ("JPEG", "PNG", "WEBP"):
                raise ValueError("脚本仅支持静态 JPG/PNG/WebP；HEIC 请先转为 JPG 或使用手机网页。")
            if getattr(source, "n_frames", 1) != 1:
                raise ValueError("不支持动图，请先选择或导出一张静态图片。")
            output_dimensions(source.width, source.height, size)
            oriented = ImageOps.exif_transpose(source)
            try:
                dimensions = output_dimensions(oriented.width, oriented.height, size)
                resized = oriented.resize(dimensions, Image.Resampling.LANCZOS)
                try:
                    rgba = resized.convert("RGBA")
                    try:
                        background = Image.new("RGBA", dimensions, "white")
                        flattened = Image.alpha_composite(background, rgba)
                        background.close()
                        result = flattened.convert("RGB")
                        flattened.close()
                        result.info.clear()
                        return result
                    finally:
                        rgba.close()
                finally:
                    resized.close()
            finally:
                oriented.close()


def allocate_folder(root):
    root.mkdir(parents=True, exist_ok=True)
    existing = [int(match.group(1)) for entry in root.iterdir() if (match := re.fullmatch(r"test_(\d+)", entry.name))]
    sequence = max(existing, default=0) + 1
    while True:
        folder = root / f"test_{sequence:04d}"
        try:
            folder.mkdir()
            return folder
        except FileExistsError:
            sequence += 1


def render_watermark(base, code, position):
    canvas = base.copy()
    draw = ImageDraw.Draw(canvas, "RGBA")
    width, height = canvas.size
    padding = max(1, round(min(width, height) * 0.025))
    font_size = max(1, round(min(width, height) * 0.046))
    font = ImageFont.load_default(size=font_size)
    while font_size > 1 and draw.textlength(code, font=font) + padding * 4 > width:
        font_size -= 1
        font = ImageFont.load_default(size=font_size)
    box_width = min(width, math.ceil(draw.textlength(code, font=font) + padding * 2))
    box_height = min(height, math.ceil(font_size * 1.6))
    left = max(0, width - box_width - padding) if position.endswith("right") else min(padding, width - box_width)
    top = max(0, height - box_height - padding) if position.startswith("bottom") else min(padding, height - box_height)
    draw.rectangle((left, top, left + box_width - 1, top + box_height - 1), fill=(15, 20, 34, 158))
    bounds = draw.textbbox((0, 0), code, font=font)
    baseline = top + (box_height - (bounds[3] - bounds[1])) / 2 - bounds[1]
    draw.text((left + padding, baseline), code, font=font, fill=(255, 255, 255, 255))
    return canvas


def make_exif(selected, identifier):
    fields = time_fields(selected)
    stamp = selected.strftime("%Y:%m:%d %H:%M:%S")
    exif = Image.Exif()
    exif[270] = f"BatchPix {identifier}"
    exif[274] = 1
    exif[305] = "BatchPix Skill"
    exif[306] = stamp
    exif[34665] = {36867: stamp, 36868: stamp, 36880: fields["offset"], 36881: fields["offset"], 36882: fields["offset"]}
    return exif


def file_md5(path):
    return hashlib.md5(path.read_bytes(), usedforsecurity=False).hexdigest()


def write_archive(folder, archive_path, selected):
    date_tuple = (selected.year, selected.month, selected.day, selected.hour, selected.minute, selected.second)
    created = False
    try:
        with archive_path.open("xb") as stream:
            created = True
            with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_STORED) as archive:
                for path in sorted(folder.iterdir()):
                    info = zipfile.ZipInfo(f"{folder.name}/{path.name}", date_time=date_tuple)
                    info.create_system = 3
                    info.external_attr = 0o100644 << 16
                    archive.writestr(info, path.read_bytes())
    except BaseException:
        if created:
            archive_path.unlink(missing_ok=True)
        raise


def generate_images(image_path, count, selected, output_root, position="bottom-right", size="2560", create_zip=False):
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= MAX_COUNT:
        raise ValueError("生成数量必须是 1–500 之间的整数。")
    if position not in POSITIONS:
        raise ValueError("水印位置无效。")
    selected = parse_time(selected.isoformat(), "UTC")
    image_path = Path(image_path).expanduser().resolve()
    root = Path(output_root).expanduser().resolve()
    base = load_source(image_path, size)
    folder = None
    try:
        original_md5 = file_md5(image_path)
        folder = allocate_folder(root)
        batch_id = uuid.uuid4().hex
        hashes = {original_md5}
        entries = []
        total_bytes = 0
        for index in range(1, count + 1):
            code = f"{index:06d}"
            path = folder / f"{code}.jpg"
            canvas = render_watermark(base, code, position)
            try:
                for attempt in range(3):
                    canvas.save(path, format="JPEG", quality=92, exif=make_exif(selected, f"{batch_id}/{code}/{uuid.uuid4().hex}"))
                    digest = file_md5(path)
                    if digest not in hashes:
                        break
                else:
                    raise RuntimeError("生成结果发生 MD5 重复，已停止。")
            finally:
                canvas.close()
            size_bytes = path.stat().st_size
            total_bytes += size_bytes
            if total_bytes > MAX_OUTPUT_BYTES or (index == 1 and size_bytes * count > MAX_OUTPUT_BYTES):
                raise ValueError("预计本批图片总量超过 180 MB，请减少数量或改用轻量尺寸。")
            hashes.add(digest)
            os.utime(path, (selected.timestamp(), selected.timestamp()))
            entries.append({"filename": path.name, "code": code, "md5": digest, "bytes": size_bytes})
        manifest = {
            "folder": folder.name,
            "source": image_path.name,
            "sourceMd5": original_md5,
            "count": count,
            "format": "JPEG",
            "dimensions": {"width": base.width, "height": base.height},
            "watermark": {"position": position, "numbering": "000001"},
            "generationTime": time_fields(selected),
            "note": "指定时间为用户设置的 EXIF 元数据，并非真实拍摄时间；MD5 仅表示文件字节差异。",
            "images": entries,
        }
        (folder / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        with (folder / "md5.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(("filename", "watermark", "md5", "exif_datetime", "timezone_offset"))
            writer.writerows((entry["filename"], entry["code"], entry["md5"], selected.strftime("%Y:%m:%d %H:%M:%S"), time_fields(selected)["offset"]) for entry in entries)
        archive_path = root / f"{folder.name}.zip" if create_zip else None
        if archive_path:
            write_archive(folder, archive_path, selected)
        return {
            "output_directory": str(folder),
            "archive": str(archive_path) if archive_path else None,
            "count": count,
            "dimensions": manifest["dimensions"],
            "generation_time": manifest["generationTime"],
            "manifest": str(folder / "manifest.json"),
            "md5_csv": str(folder / "md5.csv"),
            "total_image_bytes": total_bytes,
        }
    except BaseException:
        if folder is not None:
            shutil.rmtree(folder, ignore_errors=True)
        raise
    finally:
        base.close()


def main():
    parser = argparse.ArgumentParser(description="基于一张原图生成独立 MD5、数字水印与指定 EXIF 时间的 JPG 批次。")
    parser.add_argument("--image", required=True, type=Path)
    parser.add_argument("--count", required=True, type=int)
    parser.add_argument("--time", help="ISO 日期时间；省略时使用当前时间。")
    parser.add_argument("--timezone", default="Asia/Shanghai", help="无偏移日期使用的 IANA 时区。默认 Asia/Shanghai。")
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--position", choices=POSITIONS, default="bottom-right")
    parser.add_argument("--size", choices=SIZES, default="2560")
    parser.add_argument("--zip", action="store_true", dest="create_zip")
    arguments = parser.parse_args()
    try:
        selected = parse_time(arguments.time, arguments.timezone)
        result = generate_images(arguments.image, arguments.count, selected, arguments.output_root, arguments.position, arguments.size, arguments.create_zip)
    except KeyboardInterrupt:
        print(json.dumps({"error": "已取消生成。"}, ensure_ascii=False), file=sys.stderr)
        return 130
    except (OSError, ValueError, RuntimeError, Image.DecompressionBombError, Image.DecompressionBombWarning) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


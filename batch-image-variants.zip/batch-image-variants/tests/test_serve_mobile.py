import importlib.util
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("batchpix_mobile_server", SKILL_ROOT / "scripts" / "serve_mobile.py")
mobile = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mobile)


class MobileServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), mobile.make_handler())
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    def request(self, method, path, body=None):
        connection = HTTPConnection("127.0.0.1", self.server.server_port)
        connection.request(method, path, body)
        response = connection.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        connection.close()
        return result

    def test_bundled_page_and_assets_work_without_node(self):
        status, headers, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("叠影".encode(), body)
        self.assertIn("text/html", headers["Content-Type"])
        for path, expected_type in (("/assets/app.js", "text/javascript"), ("/assets/index.css", "text/css"), ("/manifest.webmanifest", "application/manifest+json"), ("/icon-192.png", "image/png"), ("/sw.js", "text/javascript")):
            with self.subTest(path=path):
                status, headers, body = self.request("GET", path)
                self.assertEqual(status, 200)
                self.assertEqual(headers["Content-Type"], expected_type)
                self.assertGreater(len(body), 0)

    def test_rejects_uploads_and_directory_traversal(self):
        self.assertEqual(self.request("POST", "/", b"photo data")[0], 405)
        for path in ("/../SKILL.md", "/scripts/generate_images.py", "/assets/"):
            with self.subTest(path=path):
                self.assertEqual(self.request("GET", path)[0], 404)

    def test_head_has_headers_without_body(self):
        status, headers, body = self.request("HEAD", "/")
        self.assertEqual(status, 200)
        self.assertGreater(int(headers["Content-Length"]), 0)
        self.assertEqual(body, b"")


if __name__ == "__main__":
    unittest.main()

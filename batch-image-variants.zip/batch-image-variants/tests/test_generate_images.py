import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

from PIL import Image


SKILL_ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("batch_image_generator", SKILL_ROOT / "scripts" / "generate_images.py")
generator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(generator)


class GenerateImagesTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="batchpix-skill-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "原图 with spaces.png"
        with Image.new("RGBA", (640, 480), (120, 150, 170, 80)) as image:
            exif = Image.Exif()
            exif[270] = "old source metadata"
            exif[34853] = {1: "N", 2: (31.0, 0.0, 0.0), 3: "E", 4: (121.0, 0.0, 0.0)}
            image.save(self.source, exif=exif)
        self.output = self.root / "generated"
        self.selected = generator.parse_time("2024-01-01T12:34:55", "Asia/Shanghai")

    def generate(self, **overrides):
        arguments = dict(image_path=self.source, count=3, selected=self.selected, output_root=self.output, create_zip=True)
        arguments.update(overrides)
        return generator.generate_images(**arguments)

    def test_unique_md5_visible_watermark_dates_and_original_unchanged(self):
        source_md5 = generator.file_md5(self.source)
        result = self.generate()
        folder = Path(result["output_directory"])
        manifest = json.loads(Path(result["manifest"]).read_text())
        self.assertEqual(result["count"], 3)
        self.assertEqual(len(list(folder.glob("*.jpg"))), 3)
        self.assertEqual(manifest["generationTime"]["offset"], "+08:00")
        self.assertEqual(manifest["generationTime"]["utc"], "2024-01-01T04:34:55Z")
        hashes = set()
        pixels = []
        for entry in manifest["images"]:
            path = folder / entry["filename"]
            digest = hashlib.md5(path.read_bytes(), usedforsecurity=False).hexdigest()
            self.assertEqual(digest, entry["md5"])
            self.assertNotEqual(digest, source_md5)
            hashes.add(digest)
            with Image.open(path) as image:
                exif = image.getexif()
                nested = exif.get_ifd(34665)
                self.assertEqual(exif[306], "2024:01:01 12:34:55")
                self.assertEqual(nested[36867], "2024:01:01 12:34:55")
                self.assertEqual(nested[36868], "2024:01:01 12:34:55")
                self.assertEqual(nested[36880], "+08:00")
                self.assertEqual(nested[36881], "+08:00")
                self.assertEqual(nested[36882], "+08:00")
                self.assertNotIn(34853, exif)
                self.assertEqual(exif[274], 1)
                pixels.append(image.tobytes())
            self.assertAlmostEqual(path.stat().st_mtime, self.selected.timestamp(), delta=1)
        self.assertEqual(len(hashes), 3)
        self.assertNotEqual(pixels[0], pixels[1])
        self.assertEqual(generator.file_md5(self.source), source_md5)

    def test_zip_contains_real_folder_matching_bytes_and_local_dos_time(self):
        result = self.generate(count=2)
        folder = Path(result["output_directory"])
        with zipfile.ZipFile(result["archive"]) as archive:
            self.assertEqual(len(archive.namelist()), 4)
            for entry in archive.infolist():
                self.assertTrue(entry.filename.startswith("test_0001/"))
                self.assertEqual(entry.date_time, (2024, 1, 1, 12, 34, 54))
                self.assertEqual(archive.read(entry), (folder / Path(entry.filename).name).read_bytes())

    def test_sequential_batches_and_cross_batch_uniqueness(self):
        first = self.generate(count=1)
        second = self.generate(count=1)
        self.assertEqual(Path(first["output_directory"]).name, "test_0001")
        self.assertEqual(Path(second["output_directory"]).name, "test_0002")
        self.assertNotEqual(generator.file_md5(Path(first["output_directory"]) / "000001.jpg"), generator.file_md5(Path(second["output_directory"]) / "000001.jpg"))
        (self.output / "test_0099").mkdir()
        third = self.generate(count=1)
        self.assertEqual(Path(third["output_directory"]).name, "test_0100")

    def test_invalid_counts_do_not_create_output(self):
        for count in (0, -1, 501, True, 1.5):
            with self.subTest(count=count), self.assertRaises(ValueError):
                self.generate(count=count)
        self.assertFalse(self.output.exists())

    def test_dates_timezones_and_nonexistent_dst_time(self):
        value = generator.parse_time("2024-01-01T00:00:00+09:00", "Asia/Shanghai")
        self.assertEqual(generator.time_fields(value)["offset"], "+09:00")
        self.assertEqual(generator.parse_time("2024-02-29", "Asia/Shanghai").day, 29)
        for value, zone in (("2023-02-29", "Asia/Shanghai"), ("1979-01-01", "UTC"), ("2108-01-01", "UTC"), ("2024-03-10T02:30:00", "America/New_York"), ("2024-01-01", "Not/AZone")):
            with self.subTest(value=value, zone=zone), self.assertRaises(ValueError):
                generator.parse_time(value, zone)

    def test_failure_cleans_only_its_new_folder(self):
        self.output.mkdir()
        preserved = self.output / "test_0001"
        preserved.mkdir()
        sentinel = preserved / "keep.txt"
        sentinel.write_text("keep")
        with patch.object(generator, "MAX_OUTPUT_BYTES", 1), self.assertRaises(ValueError):
            self.generate()
        self.assertEqual(sentinel.read_text(), "keep")
        self.assertEqual(list(self.output.iterdir()), [preserved])

    def test_existing_zip_is_not_overwritten(self):
        self.output.mkdir()
        archive = self.output / "test_0001.zip"
        archive.write_bytes(b"existing user file")
        with self.assertRaises(FileExistsError):
            self.generate(count=1)
        self.assertEqual(archive.read_bytes(), b"existing user file")
        self.assertFalse((self.output / "test_0001").exists())

    def test_orientation_is_applied_and_transparency_is_flattened(self):
        with Image.new("RGB", (80, 120), "white") as image:
            exif = Image.Exif()
            exif[274] = 6
            path = self.root / "rotated.jpg"
            image.save(path, exif=exif)
        rotated = self.generate(image_path=path, count=1)
        self.assertEqual(rotated["dimensions"], {"width": 120, "height": 80})
        with Image.new("RGBA", (80, 120), (0, 0, 0, 0)) as image:
            path = self.root / "transparent.png"
            image.save(path)
        transparent = self.generate(image_path=path, count=1)
        with Image.open(Path(transparent["output_directory"]) / "000001.jpg") as image:
            self.assertEqual(image.getpixel((0, 0)), (255, 255, 255))

    def test_collision_detection_stops_instead_of_delivering_duplicates(self):
        with patch.object(generator, "file_md5", return_value="same-md5"), self.assertRaises(RuntimeError):
            self.generate(count=2)
        self.assertEqual(list(self.output.iterdir()), [])

    def test_parallel_directory_allocation(self):
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda index: self.generate(count=1), range(2)))
        self.assertEqual({Path(result["output_directory"]).name for result in results}, {"test_0001", "test_0002"})

    def test_cli_runs_from_an_unrelated_working_directory(self):
        completed = subprocess.run([sys.executable, str(SKILL_ROOT / "scripts" / "generate_images.py"), "--image", str(self.source), "--count", "2", "--time", "2024-01-01", "--output-root", str(self.output), "--zip"], cwd=self.root, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        result = json.loads(completed.stdout)
        self.assertTrue(Path(result["archive"]).is_file())
        self.assertEqual(result["generation_time"]["local"], "2024-01-01T00:00:00")

    def test_rejects_missing_and_unsupported_input(self):
        with self.assertRaises(ValueError):
            self.generate(image_path=self.root / "missing.png")
        path = self.root / "unsupported.gif"
        with Image.new("RGB", (80, 80)) as image:
            image.save(path)
        with self.assertRaises(ValueError):
            self.generate(image_path=path)
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()

